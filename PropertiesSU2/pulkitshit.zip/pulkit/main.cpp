#include <iostream>
#include <fstream>
using namespace std;
#include "../../SU2-fork/Common/include/mpi_structure.hpp"
#include "../../SU2-fork/SU2_CFD/include/fluid_model.hpp"
#include "../../SU2-fork/SU2_CFD/src/fluid_model_pig.cpp"
#include "../../SU2-fork/SU2_CFD/src/fluid_model_ppr.cpp"
#include "../../SU2-fork/SU2_CFD/src/fluid_model_pvdw.cpp"
#include "../../SU2-fork/SU2_CFD/src/fluid_model.cpp"
#include "../../SU2-fork/SU2_CFD/src/transport_model.cpp"
#include "../../SU2-fork/SU2_CFD/include/transport_model.hpp"










int main() 
{
    su2double P = 1e5;//something;			//
    su2double T = 500.;//something;			//
    su2double Mach = 1.5;			//
    su2double R = 90.15;			//
    su2double Pstar = 4126300.0; 	//critical pressure toluene
    su2double Tstar = 591.75;		//critical temperature toluene
    su2double w = 0.2657;
    su2double gamma = 1.06;
    //transport propert

   //fluid properties
    CPengRobinson *FluidModelPRstatic = new CPengRobinson(gamma, R, Pstar, Tstar, w);
    CPengRobinson *FluidModelPRtotal = new CPengRobinson(gamma, R, Pstar, Tstar, w);
    FluidModelPRstatic->SetTDState_PT(P,T);
    su2double h = FluidModelPRstatic->GetStaticEnergy() + FluidModelPRstatic->GetPressure()/FluidModelPRstatic->GetDensity();
    su2double c = Mach*FluidModelPRstatic->GetSoundSpeed();
    su2double h0 = h + (c*c)/2;
    su2double s = FluidModelPRstatic->GetEntropy();
    FluidModelPRtotal->SetTDState_hs(h0,s);

    cout << FluidModelPRtotal->GetPressure() << endl;
    cout << FluidModelPRtotal->GetTemperature() << endl;


//    FluidModelPR->SetThermalConductivityModel2(ViscocityModelToluene);
//    CVanDerWaalsGas *FluidModelVDW = new CVanDerWaalsGas(gamma, R, Pstar, Tstar);



//    su2double T, rho;
//    T=300.0;rho=0.0;
//    ViscocityModelToluene->SetViscosity(T,rho);
//    cout << ViscocityModelToluene->GetViscosity() << '\n';
//    T=400.0;rho=0.0;
//    ViscocityModelToluene->SetViscosity(T,rho);
//    cout << ViscocityModelToluene->GetViscosity() << '\n';
//    T=550.0;rho=0.0;
//    ViscocityModelToluene->SetViscosity(T,rho);
//    cout << ViscocityModelToluene->GetViscosity() << '\n';
//    T=300.0;rho=865.0;
//    ViscocityModelToluene->SetViscosity(T,rho);
//    cout << ViscocityModelToluene->GetViscosity() << '\n';
//    T=400.0;rho=770.0;
//    ViscocityModelToluene->SetViscosity(T,rho);
//    cout << ViscocityModelToluene->GetViscosity() << '\n';
//    T=550.0;rho=550.0;
//    ViscocityModelToluene->SetViscosity(T,rho);
//    cout << ViscocityModelToluene->GetViscosity() << '\n';
//

    return 0;

}
